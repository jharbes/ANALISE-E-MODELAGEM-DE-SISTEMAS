Baixar o programa Astah para desenvolvimento de diagramas
https://astah.net/downloads/ -> Astah UML -> For Academic (I am a student)
